﻿AWS-cloud-static-Udacity
🌐 Deploy Static Website on AWS
🧠 Project Overview


This project demonstrates how to deploy a static website on AWS using the following key services:


Amazon S3 – to host the website files


Amazon CloudFront – to distribute content globally with low latency


AWS IAM – to manage access and permissions securely


```
📂 Project Structure
/
├── index.html          # The main HTML file (homepage)
├── /img                # Folder containing background and image assets
├── /vendor             # Bootstrap, Font Awesome, and JS library dependencies
├── /css                # Custom CSS styles for the website
└── README.txt          # Project description and setup guide
└── /Screenshots        # Project screenshots




```
🚀 Deployment Steps
1. Create an S3 Bucket


- Open the AWS S3 Console


- Click Create bucket and enter a unique bucket name (e.g., my-demo-bucket-531807)
    


- Uncheck Block all public access
  
  


- Enable Static website hosting under Properties


- Set the index document to index.html
    


2. Upload Website Files


- Upload all files and folders:








- index.html
- /img
- /vendor
- /css


- Then make the files publicly readable (via permissions or bucket policy).
  





3. Set Bucket Policy


Add the following bucket policy to allow public read access:


```
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::your-bucket-name/*"
    }
  ]
}
```
  



4. Configure CloudFront 


- Go to CloudFront Console → Create Distribution




- Go to origin → Choose your S3 bucket
  
 


- Go to Behaviors → Enable Redirect HTTP to HTTPS for security
  
  


- Deploy — you’ll get a CloudFront URL to access your site globally
    


















Verify Your Website
Open your CloudFront URL or S3 website endpoint in a browser.Your static website should now be live


Live S3 Website URL: http://my-demo-bucket-531807.s3-website-us-east-1.amazonaws.com/


  



Live CloudFront URL: https://d2b29ywfrwec1n.cloudfront.net/


  



















👩‍💻 Technologies Used


```
HTML5


CSS3


Bootstrap (via /vendor/)


Font Awesome


Amazon S3


Amazon CloudFront


AWS IAM
```


🏁 Expected Outcome


```
By completing this project, you will:


Understand AWS S3 static website hosting


Learn how to configure CloudFront for global distribution


Manage IAM permissions and bucket policies securely


Successfully deploy and host a professional static website
```